<?php
session_start();

$conn = mysqli_connect(
  'localhost',
  'id21456883_andhree',
  'Andhree_936885946',
  'id21456883_php_mysql_crud'
) or die(mysqli_erro($mysqli));

?>
